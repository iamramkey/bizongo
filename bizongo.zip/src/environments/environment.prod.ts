export const environment = {
  production: true,
  assetsUrl: 'assets/',
  gamesListUrl: 'games.csv'
};
